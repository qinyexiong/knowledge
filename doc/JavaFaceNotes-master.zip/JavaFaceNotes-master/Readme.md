最近很多小伙伴问我要面试题，但面试题大多都比较零散，所以博主整理了一下，有一部分是从互联网收集整理所得，还有一部分是小咖自己从专栏、书籍学习所得。
目前有31个专题，277页。全文阅读时间可能几个小时，但是整理和创作要花的时间就要比阅读的时间多出至少十倍。

小编后面阅读书籍以及专栏等所得的部分，请不要直接发到互联网申请原创，如果要发请注明来源。
小编会持续的更新维护。大家可以加我微信进入群内，vx:baiseyumaoxx。一旦更新，我会通知大家。

手册是第二个版本了已经，原来是17个专题，新增了14个专题，希望对大家有用。

目前有如下专题:

Java基础、Java集合、异常&反射、IO&NIO、Java多线程、JVM、Linux、MySql、Spring、Mybatis、Nginx、Redis、Dubbo、SpringBoot、Kafka、Spring Cloud、简历

Netty、计算机基础、MongoDB、JSP、Servlet、Elasticsearch、Web安全、Tomcat、Zookeeper、Maven、Git、RabbitMQ、Java8、JVM


具体大家需要看的部分点击目录即可查看。pdf给大家准备好了。小编会持续更新...

扫描二维码回复：“面试2”即可获取pdf

![WechatIMG360](https://gitee.com/yizhibuerdai/Imagetools/raw/master/images/common1.png)
